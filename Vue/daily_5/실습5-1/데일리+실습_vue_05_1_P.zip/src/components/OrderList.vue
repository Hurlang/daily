<template>
  <div>
  </div>
</template>

<script>
export default {
  name: 'OrderList',
  computed: {
    orderList: function () {
    },
    totalOrderCount: function () {
    },
    totalOrderPrice: function () {
    },
  },
}
</script>

<style>
</style>