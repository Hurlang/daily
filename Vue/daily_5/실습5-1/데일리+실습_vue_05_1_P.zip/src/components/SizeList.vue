<template>
  <div>
    <h1>2. 사이즈를 고르세요.</h1>
  </div>
</template>

<script>
export default {
  name: 'SizeList',
  methods: {
    onSelectMenu: function () {},
  },
  computed: {
    sizeList: function () {},
  },
}
</script>

<style>
</style>