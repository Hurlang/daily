<template>
  <div class="menu-list">
    <h1>1. 음료를 고르세요.</h1>
  </div>
</template>

<script>

export default {
  name: 'MenuList',
  components: {
    MenuListItem
  },
  computed: {
    menuList: function () {},
  },
  methods: {
    selectMenu: function () {},
  },
}
</script>

<style>

</style>