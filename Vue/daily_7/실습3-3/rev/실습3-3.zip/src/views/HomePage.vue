<template>
  <div>
    <h2>Start 버튼으로 시작해 보세요!</h2>
      <img src="../assets/ssafy-banner.png" alt=".">
  </div>
</template>

<script>
export default {
  name: 'HomePage'
}
</script>

<style>

</style>