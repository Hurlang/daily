<template>
  <div class="box">
    <h2>찾으시려는 페이지가 존재하지 않습니다!</h2>
    <div>
      <img src="../assets/noResult.png" alt=".">
    </div>
  </div>
</template>

<script>
export default {
  name: 'NoColor'
}
</script>

<style>

</style>