const member = {
  name: 'aiden',
  age: 22,
  sId: 2022311491,
}

// const member2 = {
//   name: 'haley',
//   age: 20,
//   sId: 2022311492,
// }

// function Member(name, age, sId) {
//   this.name = name
//   this.age = age
//   this.sId = sId
// }

// const member3 = new Member('isaac', 21, 2022654321)